import React from 'react';
import { Star, Quote, Shield, Package, Clock } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Bride",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      text: "The engagement ring from Luxe Jewelry exceeded all my expectations. The custom design process was seamless, and the final result was absolutely breathtaking. I get compliments every single day!",
      rating: 5
    },
    {
      name: "Michael Chen",
      role: "Anniversary Gift",
      image: "https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      text: "For our 25th anniversary, I wanted something truly special. The team at Luxe Jewelry created a stunning necklace that brought tears to my wife's eyes. Their craftsmanship is unmatched.",
      rating: 5
    },
    {
      name: "Emily Rodriguez",
      role: "Collector",
      image: "https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      text: "I've been a customer for over 10 years, and the quality never disappoints. From everyday pieces to special occasion jewelry, Luxe Jewelry has been my go-to for all things beautiful.",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">What Our Customers Say</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it - hear from the thousands of satisfied customers who have made 
            Luxe Jewelry part of their most precious moments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-8 relative">
              <Quote className="w-8 h-8 text-yellow-600 mb-4" />
              <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.text}"</p>
              
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>

              <div className="flex items-center">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full mr-4 object-cover"
                />
                <div>
                  <h4 className="font-semibold text-slate-900">{testimonial.name}</h4>
                  <p className="text-gray-600 text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-center">
              <div className="bg-yellow-100 p-4 rounded-full mb-3">
                <Shield className="w-8 h-8 text-yellow-600" />
              </div>
              <h4 className="font-semibold text-slate-900">Lifetime Warranty</h4>
              <p className="text-gray-600 text-sm">On all custom pieces</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-yellow-100 p-4 rounded-full mb-3">
                <Star className="w-8 h-8 text-yellow-600" />
              </div>
              <h4 className="font-semibold text-slate-900">5-Star Rating</h4>
              <p className="text-gray-600 text-sm">Across all platforms</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-yellow-100 p-4 rounded-full mb-3">
                <Package className="w-8 h-8 text-yellow-600" />
              </div>
              <h4 className="font-semibold text-slate-900">Free Shipping</h4>
              <p className="text-gray-600 text-sm">On orders over $500</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-yellow-100 p-4 rounded-full mb-3">
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
              <h4 className="font-semibold text-slate-900">30-Day Returns</h4>
              <p className="text-gray-600 text-sm">No questions asked</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;