import React, { useState } from 'react';
import { Menu, X, Phone, MapPin } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <>
      {/* Top Bar */}
      <div className="bg-slate-900 text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Phone className="w-4 h-4" />
              <span>(555) 123-4567</span>
            </div>
            <div className="flex items-center space-x-1">
              <MapPin className="w-4 h-4" />
              <span>123 Diamond Street, New York, NY 10001</span>
            </div>
          </div>
          <div className="hidden md:block">
            <span>Mon-Sat: 10AM-8PM | Sun: 12PM-6PM</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <div className="flex items-center">
              <h1 className="text-3xl font-bold text-slate-900">
                <span className="text-yellow-600">Luxe</span> Jewelry
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="#home" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Home</a>
              <a href="#products" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Collections</a>
              <a href="#about" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">About Us</a>
              <a href="#services" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Services</a>
              <a href="#contact" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Contact</a>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t">
              <nav className="flex flex-col space-y-4">
                <a href="#home" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Home</a>
                <a href="#products" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Collections</a>
                <a href="#about" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">About Us</a>
                <a href="#services" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Services</a>
                <a href="#contact" className="text-slate-700 hover:text-yellow-600 font-medium transition-colors">Contact</a>
              </nav>
            </div>
          )}
        </div>
      </header>
    </>
  );
};

export default Header;