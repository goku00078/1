import React from 'react';
import { Heart, Eye, ShoppingBag } from 'lucide-react';

const Products = () => {
  const categories = [
    {
      title: "Diamond Rings",
      description: "Engagement & Wedding Rings",
      image: "https://images.pexels.com/photos/1468379/pexels-photo-1468379.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
      price: "From $2,500"
    },
    {
      title: "Luxury Necklaces",
      description: "Statement & Delicate Pieces",
      image: "https://images.pexels.com/photos/1721342/pexels-photo-1721342.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
      price: "From $800"
    },
    {
      title: "Elegant Earrings",
      description: "Studs, Hoops & Drops",
      image: "https://images.pexels.com/photos/1721338/pexels-photo-1721338.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
      price: "From $400"
    },
    {
      title: "Designer Bracelets",
      description: "Tennis & Chain Bracelets",
      image: "https://images.pexels.com/photos/1721339/pexels-photo-1721339.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
      price: "From $600"
    },
    {
      title: "Luxury Watches",
      description: "Swiss & Designer Timepieces",
      image: "https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
      price: "From $1,200"
    },
    {
      title: "Gemstone Collection",
      description: "Precious & Semi-Precious Stones",
      image: "https://images.pexels.com/photos/1721340/pexels-photo-1721340.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop",
      price: "From $300"
    }
  ];

  return (
    <section id="products" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Our Collections</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover our carefully curated selection of fine jewelry, each piece telling its own story of elegance and craftsmanship.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden group hover:shadow-xl transition-shadow duration-300">
              <div className="relative overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-30 transition-opacity duration-300"></div>
                <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button className="bg-white p-2 rounded-full hover:bg-yellow-600 hover:text-white transition-colors">
                    <Heart className="w-5 h-5" />
                  </button>
                  <button className="bg-white p-2 rounded-full hover:bg-yellow-600 hover:text-white transition-colors">
                    <Eye className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-slate-900 mb-2">{category.title}</h3>
                <p className="text-gray-600 mb-4">{category.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-yellow-600">{category.price}</span>
                  <button className="bg-slate-900 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors duration-300">
                    <ShoppingBag className="w-4 h-4" />
                    <span>View</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;