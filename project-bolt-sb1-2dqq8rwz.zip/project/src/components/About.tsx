import React from 'react';
import { Award, Users, Clock, Gem } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Clock, number: "38+", label: "Years of Excellence" },
    { icon: Users, number: "50,000+", label: "Happy Customers" },
    { icon: Award, number: "25+", label: "Design Awards" },
    { icon: Gem, number: "10,000+", label: "Unique Pieces" }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Image */}
          <div className="relative">
            <img 
              src="https://images.pexels.com/photos/1927259/pexels-photo-1927259.jpeg?auto=compress&cs=tinysrgb&w=600&h=700&fit=crop"
              alt="Jewelry craftsman at work"
              className="rounded-lg shadow-xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-yellow-600 text-white p-6 rounded-lg">
              <p className="text-2xl font-bold">Since 1985</p>
              <p className="text-sm">Crafting Dreams</p>
            </div>
          </div>

          {/* Right Column - Content */}
          <div>
            <h2 className="text-4xl font-bold text-slate-900 mb-6">Our Story</h2>
            <p className="text-lg text-gray-600 mb-6">
              Founded in 1985 by master jeweler Maria Gonzalez, Luxe Jewelry began as a small family business 
              with a simple mission: to create extraordinary pieces that celebrate life's most precious moments.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Today, we continue that legacy with the same dedication to craftsmanship, quality, and personal 
              service that has made us one of the most trusted names in fine jewelry. Each piece in our collection 
              is carefully selected or custom-crafted to meet the highest standards of beauty and durability.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              From engagement rings that mark the beginning of forever to heirloom pieces passed down through 
              generations, we're honored to be part of your most meaningful moments.
            </p>

            {/* Values */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="bg-yellow-100 p-2 rounded-full">
                  <Gem className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">Exceptional Quality</h4>
                  <p className="text-gray-600">Only the finest materials and gemstones make it into our collection.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="bg-yellow-100 p-2 rounded-full">
                  <Users className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">Personal Service</h4>
                  <p className="text-gray-600">Every customer receives individualized attention and expert guidance.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="bg-yellow-100 p-2 rounded-full">
                  <Award className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">Master Craftsmanship</h4>
                  <p className="text-gray-600">Time-honored techniques combined with modern innovation.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-3xl font-bold text-slate-900 mb-2">{stat.number}</h3>
              <p className="text-gray-600">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;