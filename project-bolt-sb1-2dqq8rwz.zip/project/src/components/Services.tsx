import React from 'react';
import { Wrench, Palette, Shield, Package } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Palette,
      title: "Custom Design",
      description: "Bring your vision to life with our bespoke jewelry design service. Our master craftsmen work with you to create one-of-a-kind pieces that reflect your personal style and story.",
      features: ["3D Design Visualization", "Personal Consultation", "Unlimited Revisions", "Lifetime Warranty"]
    },
    {
      icon: Wrench,
      title: "Expert Repairs",
      description: "Trust our certified jewelers to restore your precious pieces to their original beauty. We handle everything from simple resizing to complex restoration work.",
      features: ["Free Estimates", "Quick Turnaround", "Certified Technicians", "Insurance Claims"]
    },
    {
      icon: Shield,
      title: "Appraisal Services",
      description: "Get accurate, certified appraisals for insurance, estate planning, or resale purposes. Our GIA-certified appraisers ensure precise valuations.",
      features: ["Insurance Appraisals", "Estate Valuations", "Certified Documentation", "Market Analysis"]
    },
    {
      icon: Package,
      title: "Jewelry Care",
      description: "Keep your jewelry looking its best with our comprehensive care services, including professional cleaning, maintenance, and storage solutions.",
      features: ["Professional Cleaning", "Maintenance Programs", "Storage Solutions", "Care Instructions"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Beyond selling beautiful jewelry, we offer comprehensive services to ensure your precious pieces 
            remain as stunning as the day you first wore them.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-6">
                <div className="bg-yellow-100 p-3 rounded-full mr-4">
                  <service.icon className="w-8 h-8 text-yellow-600" />
                </div>
                <h3 className="text-2xl font-semibold text-slate-900">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <div className="w-2 h-2 bg-yellow-600 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
              <button className="mt-6 bg-slate-900 hover:bg-yellow-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-300">
                Learn More
              </button>
            </div>
          ))}
        </div>

        {/* Process Section */}
        <div className="mt-20">
          <h3 className="text-3xl font-bold text-slate-900 text-center mb-12">Our Process</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Consultation", desc: "We listen to your vision and discuss your needs" },
              { step: "02", title: "Design", desc: "Our experts create detailed designs and 3D renderings" },
              { step: "03", title: "Crafting", desc: "Master jewelers bring your piece to life with precision" },
              { step: "04", title: "Delivery", desc: "Your finished piece is presented in luxury packaging" }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="bg-yellow-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {item.step}
                </div>
                <h4 className="text-lg font-semibold text-slate-900 mb-2">{item.title}</h4>
                <p className="text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;